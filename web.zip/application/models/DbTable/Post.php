<?php

class Application_Model_DbTable_Post extends Zend_Db_Table_Abstract
{
    /** Table name */
    protected $_name    = 'frontend_post';

    
}